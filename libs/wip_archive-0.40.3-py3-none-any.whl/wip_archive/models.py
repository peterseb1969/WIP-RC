"""Pydantic models for export manifests and statistics."""

from __future__ import annotations

import re
from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field

_V3_FORMAT = re.compile(r"3(\.\d+)?")


class NamespaceConfig(BaseModel):
    """Namespace configuration from the Registry.

    allowed_external_refs, deletion_mode and inbound_references default to
    None, not to the platform defaults: None means "this archive predates
    the field" and the restore upsert must OMIT it (leaving an existing
    namespace's config untouched), while an explicit value — including an
    empty list — is applied. A [] default would make restoring an old archive actively
    clear an existing namespace's allowlist.
    """
    prefix: str
    # The namespace's identity on its source. Required: an ID-preserving
    # restore re-creates the namespace under it, so the orphaned grants a
    # system restore wrote for it are activated; an archive without it
    # predates namespace ids and is refused.
    namespace_id: str
    description: str = ""
    isolation_mode: str = "open"
    id_config: dict[str, Any] | None = None
    allowed_external_refs: list[str] | None = None
    deletion_mode: str | None = None
    # Same None rule: an archive from before inbound references existed
    # omits the field, and the namespace keeps (or gets) its own setting.
    inbound_references: str | None = None


class ClosureInfo(BaseModel):
    """Information about referential integrity closure."""
    external_terminologies: list[str] = Field(default_factory=list)
    external_templates: list[str] = Field(default_factory=list)
    iterations: int = 0
    warnings: list[str] = Field(default_factory=list)


class EntityCounts(BaseModel):
    """Counts of each entity type in the archive."""
    terminologies: int = 0
    terms: int = 0
    term_relations: int = 0
    templates: int = 0
    documents: int = 0
    files: int = 0
    registry_entries: int = 0

    @property
    def total(self) -> int:
        return (
            self.terminologies + self.terms + self.term_relations
            + self.templates + self.documents + self.files
            + self.registry_entries
        )


class NamespaceEntry(BaseModel):
    """One namespace's slice of a multi-namespace (v3) archive.

    A v3 archive carries a list of these on the manifest; each maps to a
    ``namespaces/<prefix>/`` subtree of JSONL files. Per-namespace config and
    counts live here (the top-level manifest ``counts`` is the aggregate).
    """
    prefix: str
    namespace_config: NamespaceConfig | None = None
    counts: EntityCounts = Field(default_factory=EntityCounts)
    # The namespace's restore history at backup time, oldest first, each
    # record as the restore engine wrote it. A restore of this archive copies
    # them into the target before appending its own record, so lineage
    # survives every backup/restore hop. None when the namespace had none, or
    # the archive predates the field (an additive field: readers ignore
    # unknown keys, so format_version is unchanged).
    provenance: list[dict[str, Any]] | None = None
    # File ids whose rows the archive carries without their bytes although it
    # was made with files: the object could not be read, or did not match the
    # file's checksum. None when every file's bytes are in it, or the archive
    # predates the field (additive, like provenance).
    files_without_bytes: list[str] | None = None
    # Inactive template versions the server backup left out by design
    # (nothing in the archive needed them), as {"template_id", "version"}: an
    # archive that lacks a version says here whether it was left out or lost.
    # Only the server backup writes it, and from it None means none was left
    # out (or include_inactive_templates). From any other producer (a
    # tool_version starting with wip-toolkit, whose export also leaves out
    # unpinned inactive versions without --include-inactive), or an archive
    # older than the field, None means not recorded.
    template_versions_left_out: list[dict[str, Any]] | None = None


class Manifest(BaseModel):
    """Archive manifest describing the export.

    **Format v3 (CASE-542)** is multi-namespace: one archive can carry N
    namespaces, each under a ``namespaces/<prefix>/`` subtree, listed in
    ``namespaces``. The top-level ``counts`` is the aggregate across all of
    them; ``namespace``/``namespace_config`` are retained only as a
    single-namespace convenience (set to the sole namespace when N==1, else
    left empty). A v2.0 (flat, single-namespace) archive is converted to v3 by
    ``wip_toolkit.convert_archive`` before the engines read it.
    """
    # 3.1: edge types declare their endpoints once, canonically. The
    # template-level source_templates / target_templates hold canonical
    # template ids, and the source_ref / target_ref endpoint constraint is no
    # longer stored — it is projected from that declaration when a template is
    # served. A 3.0 reader restoring a 3.1 archive therefore finds no stored
    # constraint on those fields, and an empty constraint means "unconstrained"
    # rather than an error, so the version is what makes the difference
    # detectable. Minor, deliberately: every gate accepts 3 and any 3.N
    # (Manifest.is_v3), so a major bump would make 3.1 archives unrestorable
    # everywhere.
    format_version: str = "3.1"
    # What wrote the archive, as "<producer> <version>" (the toolkit's
    # exporter, document-store's backup engine). Empty when the archive does
    # not say: a constant default here once made every archive claim 0.5.0.
    tool_version: str = ""
    # When the archive was written. None when the archive does not say: a
    # "now" default here once made every reader report the moment it read
    # the archive as its export time. An archive-making writer sets it;
    # convert-archive copies it only when the source archive has one.
    exported_at: datetime | None = None
    source_host: str = ""
    # v3: the authoritative list of namespaces in this archive.
    namespaces: list[NamespaceEntry] = Field(default_factory=list)
    # Single-namespace convenience (mirrors namespaces[0] when len==1).
    namespace: str = ""
    namespace_config: NamespaceConfig | None = None
    source_install: dict[str, Any] | None = None
    # include_inactive was removed from the manifest: the backup exports every
    # entity in every status a document, template or term still needs, so the
    # flag carried no signal about what an archive holds. What it does skip is
    # stated by the fields that remain: include_files for the bytes,
    # include_all_versions for versions, and each namespace's
    # template_versions_left_out for the template versions the server backup
    # dropped because nothing in the archive pins them (another producer
    # does not record them; see NamespaceEntry).
    include_files: bool = False
    include_all_versions: bool = False
    closure: ClosureInfo = Field(default_factory=ClosureInfo)
    counts: EntityCounts = Field(default_factory=EntityCounts)
    # Rows in referents.jsonl: the Registry entries of entities the archive
    # references but does not carry (wip_archive.referents). None = the
    # archive predates the table, so a restore cannot tell "nothing
    # external" from "not recorded" and must fall back to each reference's
    # own lookup half. Additive, like provenance: older readers ignore it,
    # so format_version is unchanged.
    referents: int | None = None

    def is_v3(self) -> bool:
        """Whether the manifest declares the v3 layout: a format_version it
        states itself (an archive without one predates version stamping; the
        model's default is not a declaration) of the form 3 or 3.N."""
        return ("format_version" in self.model_fields_set
                and _V3_FORMAT.fullmatch(self.format_version) is not None)

    def format_label(self) -> str:
        """The format the manifest states, for a message: "v3.1", or that it
        states none."""
        if "format_version" not in self.model_fields_set:
            return "unstated (the manifest has no format_version)"
        return f"v{self.format_version}"

    def namespace_prefixes(self) -> list[str]:
        """The namespaces carried by this archive.

        Reads the v3 ``namespaces`` list; falls back to the single-namespace
        ``namespace`` field for a converted/legacy-shaped manifest where the
        list wasn't populated.
        """
        if self.namespaces:
            return [n.prefix for n in self.namespaces]
        return [self.namespace] if self.namespace else []


class ExportStats(BaseModel):
    """Statistics for an export operation."""
    namespace: str
    counts: EntityCounts = Field(default_factory=EntityCounts)
    closure_iterations: int = 0
    external_terminologies: int = 0
    external_templates: int = 0
    warnings: list[str] = Field(default_factory=list)
    duration_seconds: float = 0.0


class ProgressEvent(BaseModel):
    """A progress event emitted by export/import orchestrators.

    Used by callers (e.g. a REST endpoint streaming SSE) to observe long-running
    backup/restore operations without parsing console output. The orchestrators
    invoke an optional ``progress_callback`` at meaningful checkpoints; this
    model is the payload.

    Conventions:
    - ``phase`` names come from two producers with different vocabularies.
      Both begin with ``"start"`` and end with ``"complete"``; a
      document-store job that fails ends with ``"error"`` (the toolkit's
      exporter raises instead). A non-fatal finding is ``"warning"`` from
      document-store's engines and ``"warning_<kind>"`` from the toolkit's
      exporter (``"warning_version_history_skipped"``,
      ``"warning_files_skipped"``); only the exact ``"warning"`` phase is
      recorded in a backup job's ``warnings``. In between, the
      toolkit's exporter emits numbered phases (``"phase_1a_entities"``,
      ``"phase_1b_documents"``, ``"phase_3_finalize"``, ...), while
      document-store's backup and restore engines emit named ones
      (``"phase_<entity type>"``, ``"phase_validate"``, ``"phase_referents"``,
      ``"phase_finalize"``, ``"phase_blobs"``, ...). A caller may use the
      phase for display or progress-bar bucketing, but should not depend on
      a particular intermediate phase appearing.
    - ``percent`` is best-effort and may be ``None`` for phases where total
      work is unknown ahead of time. When set, it covers 0-100 across the
      whole operation, not the current phase.
    - ``current`` and ``total`` apply within a phase (e.g. document N of M).
    - ``message`` is a short, human-readable line suitable for a status row.
    - ``details`` carries phase-specific structured fields when useful.
    """
    phase: str
    message: str
    percent: float | None = None
    current: int | None = None
    total: int | None = None
    details: dict[str, Any] = Field(default_factory=dict)


class ImportStats(BaseModel):
    """Statistics for an import operation."""
    mode: str  # "restore" or "fresh"
    source_namespace: str = ""
    target_namespace: str = ""
    created: EntityCounts = Field(default_factory=EntityCounts)
    skipped: EntityCounts = Field(default_factory=EntityCounts)
    failed: EntityCounts = Field(default_factory=EntityCounts)
    id_mappings: int = 0
    synonyms_registered: int = 0
    warnings: list[str] = Field(default_factory=list)
    errors: list[str] = Field(default_factory=list)
    duration_seconds: float = 0.0
