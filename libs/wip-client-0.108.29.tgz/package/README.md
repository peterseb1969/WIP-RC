# @wip/client

TypeScript client library for WIP (World In a Pie) services. Framework-agnostic, zero runtime dependencies, uses native `fetch`. Works in browsers and Node.js 18+.

## Critical Behaviors

Before writing any code, understand these non-obvious behaviors that cause the most confusion:

### Bulk-First API: HTTP 200 Does Not Mean Success

Every WIP write endpoint is bulk. It accepts an array and **always returns HTTP 200** — even when items fail. Errors are per-item inside `results[]`.

```typescript
const response = await client.defStore.createTerminologies([
  { value: 'VALID', label: 'Valid' },
  { value: 'DUPLICATE', label: 'Duplicate' },  // already exists
])

// response.results[0].status === "created"  ✓
// response.results[1].status === "error"    ✗  but HTTP was still 200!
// response.succeeded === 1, response.failed === 1
```

**Single-item convenience methods** (e.g., `createTerminology()`) wrap the bulk API and **throw `WipBulkItemError`** if the item fails. Bulk methods (e.g., `createTerminologies()`, `createTerms()`, `createDocuments()`) return `BulkResponse` — you must check `results[i].status` yourself.

### Document Identity: Same Data = Same ID, New Version

Templates define `identity_fields` (e.g., `["email"]`). When you create a document, the identity fields are hashed (SHA-256) and sent to the Registry. If the hash matches an existing document, you get the **same `document_id`** with an incremented `version` — this is an upsert, not a duplicate.

```typescript
// First call: creates version 1
await client.documents.createDocument({
  template_id: 'PATIENT_RECORD',
  namespace: 'wip',
  data: { email: 'jane@example.com', name: 'Jane' },
})

// Second call with same email: creates version 2 of the SAME document (NOT a new document)
await client.documents.createDocument({
  template_id: 'PATIENT_RECORD',
  namespace: 'wip',
  data: { email: 'jane@example.com', name: 'Jane Doe' },  // name changed
})
```

**Zero identity fields** = every submission creates a new document (append-only, no update path). **Too many identity fields** = corrections create duplicates instead of new versions. Never include timestamps or per-run data in identity fields.

### Template Versioning: Multiple Active Versions

When you update a template, the `template_id` stays the same but `version` increments. **Both versions remain active simultaneously.** Documents pin to a specific `(template_id, version)`.

```typescript
// Get latest version (default)
const latest = await client.templates.getTemplate('TPL-001')

// Get specific version
const v1 = await client.templates.getTemplate('TPL-001', 1)

// List documents for a specific template version
const docs = await client.documents.listDocuments({
  template_id: 'TPL-001',
  template_version: 1,
})
```

### Soft Delete: Nothing Is Really Deleted

All delete operations default to setting `status: "inactive"` — records remain in the database. The exceptions are opt-in: `files.hardDeleteFile()` permanently removes the file from object storage, and `deleteDocument` / `deleteTemplate` / `deleteTerminology` / `deleteTerm` accept a `hardDelete` option (subject to the namespace's `deletion_mode` and, for terms, the terminology's `mutable` flag).

### Retry Behavior

GET requests retry automatically on 502/503/504 with exponential backoff (default: 2 retries). **POST/PUT/DELETE never retry** — mutations fail immediately on any error. This prevents double-creates.

---

## Quick Start

```typescript
import { createWipClient } from '@wip/client'

const client = createWipClient({
  baseUrl: `${import.meta.env.BASE_URL}wip`,  // In browser: the app's @wip/proxy mount
  auth: { type: 'api-key', key: 'dev_master_key_for_testing' },
})

// List terminologies
const terminologies = await client.defStore.listTerminologies({ status: 'active' })

// Create a terminology (single-item convenience — throws on error)
const result = await client.defStore.createTerminology({
  value: 'GENDER',
  label: 'Gender',
  namespace: 'wip',
})
console.log(result.id) // UUID7

// Bulk create terms (returns BulkResponse — check results[] yourself)
const bulkResult = await client.defStore.createTerms('GENDER', [
  { value: 'MALE', label: 'Male' },
  { value: 'FEMALE', label: 'Female' },
], { namespace: 'wip' })
console.log(bulkResult.succeeded) // 2
```

## Installation

Local package — reference via `file:` or tgz in consumer's `package.json`:

```json
{
  "dependencies": {
    "@wip/client": "file:../../libs/wip-client"
  }
}
```

Zero runtime dependencies. Requires Node.js 18+ (for native `fetch` and `FormData`). Works in all modern browsers.

## Configuration

```typescript
import { createWipClient, ApiKeyAuthProvider, OidcAuthProvider } from '@wip/client'

const client = createWipClient({
  // Required: base URL of your WIP instance
  // In browser behind the app's @wip/proxy mount: `${import.meta.env.BASE_URL}wip`
  //   (an app is served at the root of its own origin, so that is '/wip')
  // In browser direct to Caddy: '' (resolved to window.location.origin)
  // For Node.js scripts: 'https://localhost:8443' or 'https://your-host:8443'
  baseUrl: `${import.meta.env.BASE_URL}wip`,

  // Auth: API key, OIDC token callback, or custom AuthProvider
  auth: { type: 'api-key', key: 'your-key' },
  // auth: { type: 'oidc', getToken: () => myOidcLib.getAccessToken() },

  // Optional: request timeout in ms (default: 30000)
  timeout: 30_000,

  // Optional: retry config for GET requests (default: 2 retries with exponential backoff)
  retry: { maxRetries: 2, baseDelayMs: 500, maxDelayMs: 5_000 },

  // Optional: called on 401 — the credentials were refused (e.g., redirect to login).
  // Not on 403: that refuses an action to a valid identity, and signing in again cannot help.
  onAuthError: () => { window.location.href = '/login' },
})

// Switch auth at runtime (e.g., after login)
client.setAuth(new ApiKeyAuthProvider('new-key'))
client.setAuth(new OidcAuthProvider(() => oidcManager.getAccessToken()))
```

### Auth Providers

| Provider | Header | Use Case |
|----------|--------|----------|
| `ApiKeyAuthProvider(key)` | `X-API-Key: <key>` | Server-side scripts, dev/testing |
| `OidcAuthProvider(getToken)` | `Authorization: Bearer <token>` | Browser apps with OIDC |

The `OidcAuthProvider` takes a callback, not a static token. It calls your function on every request, so token refresh is handled by your OIDC library. The provider has **zero OIDC dependencies** — bring your own library (oidc-client-ts, Auth0, etc.).

API key auth headers are cached internally for performance (the key is static; the cache clears on a 401/403 or `setAuth()`). To rotate a key on a live client, call `client.setAuth(new ApiKeyAuthProvider(newKey))`. OIDC headers call your `getToken` callback fresh on every request, so a token your OIDC library rotates is always current — the transport never pins a stale bearer.

---

## Services

| Service | Property | Exported class | Port | Description |
|---------|----------|----------------|------|-------------|
| Def-Store | `client.defStore` | `DefStoreService` | 8002 | Terminologies, terms, validation, ontology, import/export |
| Template-Store | `client.templates` | `TemplateStoreService` | 8003 | Document schemas, versioning, draft mode, inheritance |
| Document-Store | `client.documents` | `DocumentStoreService` | 8004 | Documents, versions, table view, CSV export, query |
| File-Store | `client.files` | `FileStoreService` | 8004 | File upload/download (object storage), orphan detection, integrity |
| Registry | `client.registry` | `RegistryService` | 8001 | Namespaces, ID management, synonyms, merge |
| Reporting-Sync | `client.reporting` | `ReportingSyncService` | 8005 | Cross-service search, integrity checks, activity feed |

The service classes (plus their abstract base `BaseService`) are exported
for typing and subclassing; in normal use you reach them through the
client properties above rather than constructing them directly. The
sections below document each service's methods through those properties.

All services route through the `baseUrl`. The Caddy reverse proxy routes `/api/def-store/*`, `/api/template-store/*`, etc. to the correct service port. The client always sends requests to `baseUrl + /api/<service>/...` — Caddy is required to route them correctly. In browser apps behind the `@wip/proxy` mount, use ``baseUrl: `${import.meta.env.BASE_URL}wip` `` — a deployed app is served at the root of its own origin (`https://<label>.<host>/`), so with Vite's default base that is `/wip`. Use `baseUrl: ''` for direct Caddy access. In Node.js scripts, use `baseUrl: 'https://your-host:8443'`.

---

## Def-Store (Terminologies & Terms)

### Terminologies

```typescript
// List with filtering and pagination
const list = await client.defStore.listTerminologies({
  status: 'active',
  value: 'COUNTRY',         // exact match on terminology code
  namespace: 'wip',
  page: 1,
  page_size: 50,            // default 50, max 100
})
// list.items: Terminology[], list.total, list.pages

// Get by ID
const terminology = await client.defStore.getTerminology('COUNTRY')

// Create (single — throws on error)
const result = await client.defStore.createTerminology({
  value: 'COUNTRY',
  label: 'Country',
  description: 'ISO 3166 countries',
  namespace: 'wip',
})
// result: { index: 0, status: "created", id: "...", value: "COUNTRY" }

// Bulk create (returns BulkResponse)
const bulk = await client.defStore.createTerminologies([
  { value: 'GENDER', label: 'Gender', namespace: 'wip' },
  { value: 'SALUTATION', label: 'Salutation', namespace: 'wip' },
])

// Update
await client.defStore.updateTerminology('COUNTRY', { label: 'Updated Label' })

// Delete (soft-delete — sets status to inactive)
await client.defStore.deleteTerminology('COUNTRY')
```

### Terms

```typescript
// List terms under a terminology
const terms = await client.defStore.listTerms('COUNTRY', {
  status: 'active',
  search: 'united',          // substring search in value/label/aliases
  page: 1,
  page_size: 50,
})

// Get single term
const term = await client.defStore.getTerm('COUNTRY:United States')

// Create single term (throws on error)
await client.defStore.createTerm('COUNTRY', {
  value: 'US',
  label: 'United States',
  aliases: ['USA', 'U.S.A.'],
}, { namespace: 'wip' })

// Bulk create terms with tuning options
const bulk = await client.defStore.createTerms('COUNTRY', terms, {
  namespace: 'wip',
  batch_size: 1000,             // items per batch (default: server-side)
  registry_batch_size: 50,      // registry calls per sub-batch
})

// Deprecate (with replacement pointer)
await client.defStore.deprecateTerm('COUNTRY:Burma', {
  reason: 'Merged with Myanmar',
  replaced_by_term_id: 'COUNTRY:Myanmar',
})

// Delete (soft-delete)
await client.defStore.deleteTerm('COUNTRY:Burma')

// Update
await client.defStore.updateTerm('COUNTRY:United States', {
  label: 'Updated Label',
  aliases: ['new-alias'],
})
```

### Validation

```typescript
// Validate a single value against a terminology
const result = await client.defStore.validateValue({
  terminology_value: 'COUNTRY',
  value: 'US',
})

// Bulk validate
const results = await client.defStore.bulkValidate({
  items: [
    { terminology_value: 'COUNTRY', value: 'US' },
    { terminology_value: 'GENDER', value: 'Male' },
  ],
})
```

### Import/Export

```typescript
// Import a complete terminology with terms
const imported = await client.defStore.importTerminology({
  terminology: { value: 'ICD10', label: 'ICD-10 Codes' },
  terms: [
    { value: 'A00', label: 'Cholera' },
    { value: 'A01', label: 'Typhoid fever' },
  ],
})
// imported.terminology, imported.terms_result (BulkResponse)

// Export
const exported = await client.defStore.exportTerminology('COUNTRY', {
  format: 'json',              // or 'csv', which resolves to the CSV text
  includeRelations: true,
  includeInactive: false,
  includeMetadata: true,
})

// Import OBO Graph JSON (ontology files like GO, HPO, MONDO)
const ontology = await client.defStore.importOntology(oboGraphJson, {
  terminology_value: 'HPO',
  terminology_label: 'Human Phenotype Ontology',
  prefix_filter: 'HP:',
  batch_size: 1000,
  registry_batch_size: 50,
})
// ontology.terms.created, ontology.relations.created, ontology.elapsed_seconds
```

### Ontology Term Relations

Term-ontology edges are "relations" (`relation_type`); document-to-document edges are "relationships" — different APIs, deliberately distinct names.

```typescript
// List relations for a term
const rels = await client.defStore.listTermRelations({
  term_id: 'ALZHEIMERS_DISEASE',
  direction: 'outgoing',        // 'incoming', 'outgoing', or 'both'
  relation_type: 'is_a',
})

// List all relations across all terminologies
const allRels = await client.defStore.listAllTermRelations({
  relation_type: 'is_a',
  status: 'active',
  page: 1,
  page_size: 50,
})

// Create relations (bulk-first; namespace is required)
await client.defStore.createTermRelations([
  { source_term_id: 'ALZHEIMERS_DISEASE', target_term_id: 'NEUROLOGY', relation_type: 'is_a' },
], 'wip')

// Traversal
// namespace is required on all four traversal calls (the service answers 422 without it).
const ancestors = await client.defStore.getAncestors('ALZHEIMERS_DISEASE', {
  relation_type: 'is_a',
  namespace: 'wip',
  max_depth: 10,
})
const descendants = await client.defStore.getDescendants('NEUROLOGY', { namespace: 'wip', max_depth: 3 })

// Direct neighbors (depth 1 by definition — no max_depth).
// relation_type defaults to is_a on the server; pass another type to
// follow part_of / regulates / ... links instead.
const parents = await client.defStore.getParents('ALZHEIMERS_DISEASE', { namespace: 'wip' })
const children = await client.defStore.getChildren('NEUROLOGY', {
  relation_type: 'part_of',
  namespace: 'wip',
})
```

---

## Template-Store (Document Schemas)

```typescript
// List templates
const templates = await client.templates.listTemplates({
  latest_only: true,            // only latest version of each template
  status: 'active',
  extends: 'BASE_RECORD',      // filter by parent template value
  namespace: 'wip',
  page: 1,
  page_size: 50,
})

// Get template (latest version by default)
const template = await client.templates.getTemplate('PATIENT_RECORD')
const v1 = await client.templates.getTemplate('PATIENT_RECORD', 1)  // specific version

// Get by value (code name)
const byValue = await client.templates.getTemplateByValue('PATIENT_RECORD')

// Get all versions of a template
const versions = await client.templates.getTemplateVersions('PATIENT_RECORD')

// Get specific version by value
const v2 = await client.templates.getTemplateByValueAndVersion('PATIENT_RECORD', 2)

// Raw variants (without resolving inheritance)
const raw = await client.templates.getTemplateRaw('PATIENT_RECORD')
const rawByValue = await client.templates.getTemplateByValueRaw('PATIENT_RECORD', 'wip')

// Create a template
await client.templates.createTemplate({
  value: 'LAB_RESULT',
  label: 'Lab Result',
  namespace: 'wip',
  identity_fields: ['patient_email', 'test_date'],
  fields: [
    { name: 'patient_email', label: 'Patient Email', type: 'string',
      mandatory: true, semantic_type: 'email', metadata: {} },
    { name: 'test_date', label: 'Test Date', type: 'date',
      mandatory: true, metadata: {} },
    { name: 'result', label: 'Result', type: 'number',
      mandatory: false, metadata: {} },
    { name: 'status', label: 'Status', type: 'term',
      mandatory: true, terminology_ref: 'LAB_STATUS', metadata: {} },
  ],
})

// Update (creates a new version — old version stays active)
await client.templates.updateTemplate('LAB_RESULT', {
  label: 'Lab Result v2',
  fields: [/* updated fields */],
})

// Delete (soft-delete)
await client.templates.deleteTemplate('LAB_RESULT', {
  version: 2,                   // delete specific version
  force: true,                  // bypass referential integrity check
})

// Validate data against a template
const validation = await client.templates.validateTemplate('LAB_RESULT', {
  data: { patient_email: 'test@example.com' },
})

// Template inheritance
const children = await client.templates.getChildren('BASE_RECORD')
const allDescendants = await client.templates.getDescendants('BASE_RECORD')

// Draft mode: create without validating references, then activate
await client.templates.createTemplate({
  value: 'DRAFT_TPL',
  label: 'Draft',
  namespace: 'wip',
  status: 'draft',              // skip reference validation
  fields: [/* ... */],
})
await client.templates.activateTemplate('DRAFT_TPL', { namespace: 'wip', dry_run: true })  // preview
await client.templates.activateTemplate('DRAFT_TPL', { namespace: 'wip' })                 // activate
```

### Field Types

| Type | Description | Special Properties |
|------|-------------|-------------------|
| `string` | Text value | `validation.pattern`, `validation.min_length`, `validation.max_length` |
| `number` | Decimal number | `validation.minimum`, `validation.maximum` |
| `integer` | Whole number | `validation.minimum`, `validation.maximum` |
| `boolean` | True/false | |
| `date` | ISO date (YYYY-MM-DD) | |
| `datetime` | ISO datetime | |
| `term` | Reference to a terminology term | `terminology_ref` (value code on write, resolved UUID on read) |
| `reference` | Reference to another document | `reference_type`, `target_templates` |
| `file` | Binary file reference | `file_config` (allowed types, max size, multiple) |
| `object` | Nested object | Child `fields` in template |
| `array` | Array of values | `array_item_type`, `array_terminology_ref` (same write/read behavior as `terminology_ref`) |

### Semantic Types

Fields can have `semantic_type` for enhanced validation and UI hints: `email`, `url`, `latitude`, `longitude`, `percentage`, `duration`, `geo_point`.

---

## Document-Store (Documents)

```typescript
// List with filtering
const docs = await client.documents.listDocuments({
  template_id: 'PATIENT_RECORD',  // accepts value code or UUID
  template_value: 'PATIENT_RECORD',  // exact value match filter
  status: 'active',
  page: 1,
  page_size: 50,
})

// Get document (latest version by default)
const doc = await client.documents.getDocument('my-document-id')
const v1 = await client.documents.getVersion('my-document-id', 1)  // specific version
const latest = await client.documents.getLatestDocument('my-document-id')

// Create document (upsert via identity hash)
const result = await client.documents.createDocument({
  template_id: 'PATIENT_RECORD',
  data: { name: 'Jane Doe', email: 'jane@example.com' },
})
// result: { status: "created", id: "...", version: 1,
//           identity_hash: "abc123...", is_new: true }

// Bulk create (returns BulkResponse)
const bulk = await client.documents.createDocuments([
  { template_id: 'PATIENT_RECORD', data: { name: 'Alice', email: 'alice@example.com' } },
  { template_id: 'PATIENT_RECORD', data: { name: 'Bob', email: 'bob@example.com' } },
])
// bulk.results[0].status, bulk.succeeded, bulk.failed

// Document versions
const versions = await client.documents.getVersions('my-document-id')

// Look up by identity hash. A hash is unique only within a template and
// namespace: pass both (templateId takes a value or id), or a hash several
// documents share answers 409 (WipConflictError) with the candidates.
const byIdentity = await client.documents.getDocumentByIdentity('abc123hash', false, 'my-ns', 'PATIENT')

// Delete (soft-delete); re-posting the document's full data brings it back
await client.documents.deleteDocument('my-document-id', 'user@example.com')

// Validate without creating
const validation = await client.documents.validateDocument({
  template_id: 'PATIENT_RECORD',
  data: { email: 'invalid' },
})
```

### Querying Documents

```typescript
// Simple query with filters
const results = await client.documents.queryDocuments({
  template_id: 'PATIENT_RECORD',
  filters: [
    { field: 'data.country', operator: 'eq', value: 'US' },
    { field: 'data.age', operator: 'gte', value: 18 },
    { field: 'data.tags', operator: 'in', value: ['urgent', 'review'] },
    { field: 'data.notes', operator: 'exists', value: true },
    { field: 'data.email', operator: 'regex', value: '@example\\.com$' },
  ],
  sort_by: 'created_at',
  sort_order: 'desc',
  page: 1,
  page_size: 50,
})
```

**Available filter operators:** `eq`, `ne`, `gt`, `gte`, `lt`, `lte`, `in`, `nin`, `exists`, `regex`.

**Scoping reads to a namespace.** Under a **multi-namespace key** (e.g. the install admin key), a value-form `template_id` / `template_value` has no namespace context to resolve against — the query then returns an explicit 422 (a loud failure; it used to be a silent `total: 0`). Pass the namespace as the second argument; it rides the `?namespace=` query param (it cannot go in the body — that is rejected `extra_forbidden`):

```typescript
const results = await client.documents.queryDocuments(
  { template_value: 'PATIENT_RECORD', filters: [] },
  'my-namespace',
)
```

`getDocument(id, version?, namespace?)` and `getDocumentByIdentity(hash, includeInactive?, namespace?, templateId?)` take the same optional namespace argument. A **single-namespace key** derives the namespace automatically, so you can omit it.

### Table View & CSV Export

```typescript
// Table view (denormalized, spreadsheet-like)
const table = await client.documents.getTableView('PATIENT_RECORD', {
  status: 'active',
  page: 1,
  page_size: 100,
})
// table.columns: [{ name, label, type, is_array, is_flattened }]
// table.rows: Record<string, unknown>[]
// table.total_documents, table.total_rows

// Export as CSV (returns Blob)
const csv = await client.documents.exportTableCsv('PATIENT_RECORD', {
  status: 'active',
  include_metadata: true,
})
```

### Migrating Documents Across Template Versions

A validated, identity-preserving bulk re-pin of a cohort from one template
version to another. The two versions must declare the same `identity_fields`
(an identity-changing move is a fork, not a migrate, and is rejected).
Dry-run first — a dry-run with `failed === 0` guarantees a successful apply,
barring concurrent writes:

```typescript
const preview = await client.documents.migrateDocuments({
  template_id: 'PATIENT_RECORD',   // UUID or registered value/synonym
  from_version: 1,
  to_version: 2,
  // dry_run defaults to true
})

if (preview.failed === 0) {
  await client.documents.migrateDocuments({
    template_id: 'PATIENT_RECORD',
    from_version: 1,
    to_version: 2,
    dry_run: false,
  })
}
// Per-document outcome in results[i]: status 'updated' | 'error'
// (error_code 'validation_failed', or 'identity_hash_stale': the stored identity
// hash is not the one the document's identity produces under to_version; re-hash
// the namespace (rehashIdentities, below) or create new documents).
// Versions that declare different identity_fields reject the whole call
// (HTTP 409, 'identity_fields_changed'), not per document.
```

### Maintenance: Rehashing Identities

A per-namespace repair pass. It requires admin permission on the namespace
and defaults to a dry run on the server. The namespace goes in the request
body.

`rehashIdentities` recomputes the identity hash of documents whose identity
fields are term- or reference-typed, so that documents written before the
resolved-referent rule carry the same hash a new write would produce. It is
synchronous (no job to poll) and slower on large namespaces. Documents that
would converge on one identity are reported as collisions and never applied.
Read `registry_status` per item: `applied` counts rewritten documents whether
or not their Registry re-key succeeded.

```typescript
const preview = await client.documents.rehashIdentities({
  namespace: 'clinic-a',
  template_values: ['ROLE_ASSIGNMENT'],   // optional filter
  // dry_run defaults to true
})
// preview.items[i].status: 'changed' | 'unresolved' | 'collision' | 'error'
// preview.collision_groups lists documents that converge on one identity

if (preview.collisions === 0 && preview.errors === 0) {
  const applied = await client.documents.rehashIdentities({
    namespace: 'clinic-a',
    template_values: ['ROLE_ASSIGNMENT'],
    dry_run: false,
  })
  // applied.items[i].registry_status: per-document Registry re-key outcome
  // applied.reporting_note: how to refresh reporting (the pass does not)
}
```

In React, use `useRehashIdentities()` from `@wip/react`.

---

## File-Store (Binary Files)

Files are stored in an S3-compatible object store (Garage) and tracked in MongoDB. The File-Store is part of the Document-Store service (same port 8004).

```typescript
// Upload a file (accepts File or Blob) into a namespace, which is required
const file = await client.files.uploadFile(myFile, 'report.pdf', {
  description: 'Monthly report',
  tags: ['report', 'monthly'],
  category: 'reports',
  allowed_templates: ['REPORT'],      // restrict which templates can reference this file
}, 'my-app')
// Without metadata: uploadFile(myFile, 'report.pdf', undefined, 'my-app')
// Every other file method takes a trailing namespace for resolving a file
// synonym; a key that can read several namespaces must pass it.
// file: FileEntity { file_id, filename, content_type, size_bytes, checksum, ... }

// List files
const files = await client.files.listFiles({
  status: 'active',
  content_type: 'application/pdf',
  page: 1,
  page_size: 50,
})

// Get file metadata
const meta = await client.files.getFile('FILE-001')

// Download — two options
const { download_url } = await client.files.getDownloadUrl('FILE-001', 3600)  // URL valid for 1 hour
const blob = await client.files.downloadFileContent('FILE-001')               // direct download

// Update metadata
await client.files.updateMetadata('FILE-001', {
  tags: ['report', 'monthly', 'reviewed'],
  description: 'Monthly report (reviewed)',
})

// Delete
await client.files.deleteFile('FILE-001')           // soft-delete (sets inactive)
await client.files.hardDeleteFile('FILE-001')        // permanent: removes from object storage

// Bulk delete
await client.files.deleteFiles(['FILE-001', 'FILE-002'])

// Bring soft-deleted files back under the same id (no re-upload). Status is
// 'reactivated', or 'unchanged' for a file that was not deleted; invalid_state
// (details.rule 'storage_missing') when the bytes are gone — upload them again.
const back = await client.files.reactivateFile('FILE-001')
await client.files.reactivateFiles(['FILE-001', 'FILE-002'])

// Find which documents reference a file
const refs = await client.files.getFileDocuments('FILE-001')

// Integrity and maintenance
const orphans = await client.files.listOrphans({ older_than_hours: 24 })
const dupes = await client.files.findByChecksum('sha256hash')
const integrity = await client.files.checkIntegrity()
// integrity.status: 'healthy' | 'warning' | 'error' | 'incomplete'
//   (incomplete: some stored objects could not be checked, nothing worse found)
// integrity.issues: [{ type: 'orphan_file' | 'missing_storage' | 'broken_reference'
//                           | 'unreclaimed_file', ... }]
```

---

## Registry (Namespaces & IDs)

The Registry is WIP's central ID authority. Services call it with composite keys; the Registry hashes keys, checks for existing entries, and either returns existing IDs or generates new ones (UUID7).

```typescript
// Namespaces
const namespaces = await client.registry.listNamespaces()
const ns = await client.registry.getNamespace('wip')
const stats = await client.registry.getNamespaceStats('wip')

// Create/manage namespaces
await client.registry.createNamespace({
  prefix: 'my-app',
  description: 'My application namespace',
})
await client.registry.updateNamespace('my-app', {
  description: 'Updated description',
  isolation_mode: 'strict',           // 'open' or 'strict'
})
await client.registry.archiveNamespace('my-app')
await client.registry.restoreNamespace('my-app')
const deletion = await client.registry.deleteNamespace('my-app', 'admin@wip.local')
// deletion.status: 'completed' | 'completed_with_warnings' | 'in_progress'.
// in_progress means a step was deferred: it is NOT done yet.
if (deletion.status === 'in_progress') {
  await client.registry.resumeDeletion('my-app')        // or let the Registry's recovery loop finish it
}
const journal = await client.registry.getDeletionStatus('my-app')  // per-step detail (platform admins)

// Initialize the default WIP namespaces (one-time setup)
await client.registry.initializeWipNamespace()

// Entry lookup
const entry = await client.registry.getEntry('E-001')
const lookup = await client.registry.lookupEntry('E-001')

// Search
const results = await client.registry.unifiedSearch({
  q: 'patient',
  namespaces: ['wip'],
  entity_types: ['documents'],
})
// Breaking in 0.28.0: returns { hits, total } (RegistryByTermHit[]), adds limit
const { hits, total } = await client.registry.searchEntries('patient record', {
  namespaces: ['wip'],
  entityTypes: ['documents'],
  limit: 20,
})

// Synonyms: map multiple keys to the same entity
await client.registry.addSynonym({
  target_id: 'E-001',
  synonym_namespace: 'external-system',
  synonym_entity_type: 'patient',
  synonym_composite_key: { mrn: '12345' },
})
await client.registry.removeSynonym({
  target_id: 'E-001',
  synonym_composite_key_hash: 'hash...',
})

// Merge: combine two entries (keeps preferred, deprecates other)
await client.registry.mergeEntries({
  preferred_id: 'E-001',
  deprecated_id: 'E-002',
})

// Deactivate
await client.registry.deactivateEntry('E-001')

// Browse all entries
const entries = await client.registry.listEntries({
  namespace: 'wip',
  entity_type: 'documents',
  page: 1,
  page_size: 50,
})
```

---

## Reporting-Sync (Search & Integrity)

Reporting-Sync maintains a PostgreSQL mirror of MongoDB data via NATS events. Use it for cross-service search, integrity checks, and activity tracking.

```typescript
// Health check
const healthy = await client.reporting.healthCheck()  // true only when status is 'healthy'; degraded is false

// Cross-service search (queries PostgreSQL)
const results = await client.reporting.search({
  query: 'patient',
  types: ['document', 'template', 'terminology'],
  status: 'active',
  limit: 50,
})
// results.results: [{ type, id, value, label, status, description, updated_at }]
// results.counts: { document: 10, template: 2, terminology: 1 }

// Referential integrity check
const integrity = await client.reporting.getIntegrityCheck({
  check_term_refs: true,
  recent_first: true,
  template_limit: 100,
  document_limit: 1000,
})
// integrity.status: 'healthy' | 'warning' | 'error' | 'partial'
// integrity.issues: [{ type, severity, entity_id, field_path, message }]

// Recent activity
// namespace is required for a key that can read several namespaces (400 otherwise);
// the same holds for getTermDocuments and getReferencedBy (a trailing namespace).
const activity = await client.reporting.getRecentActivity({
  types: 'document,template',
  limit: 20,
  namespace: 'my-app',
})
// activity.activities: [{ type, action, entity_id, timestamp, user, version }]
// activity.incomplete_sources: entity types whose service could not be read —
// their activity is missing, not absent. Check it before reading "nothing changed".

// Reference tracking
const refs = await client.reporting.getEntityReferences('document', 'my-document-id')
const usedBy = await client.reporting.getReferencedBy('terminology', 'COUNTRY', 50)
// A term is its id or 'ns:TERMINOLOGY:value' — the 2-part 'COUNTRY:United States' is refused
const termDocs = await client.reporting.getTermDocuments('my-app:COUNTRY:United States', 100)
```

---

## Error Handling

### Error Hierarchy

All errors extend `WipError`:

| Error Class | HTTP Status | When |
|-------------|------------|------|
| `WipNotFoundError` | 404 | Entity doesn't exist |
| `WipValidationError` | 400, 422 | Invalid request data (note: `err.statusCode` always reads 422, even when the server returned 400) |
| `WipConflictError` | 409 | Conflict (rare — most conflicts are per-item in BulkResponse) |
| `WipAuthError` | 401, 403 | Bad/missing credentials or insufficient permissions |
| `WipServerError` | 5xx | Server-side error |
| `WipNetworkError` | — | Network timeout or connection failure |
| `WipBulkItemError` | — | Single-item convenience method when the item's `status === "error"` |

```typescript
import {
  WipError, WipNotFoundError, WipValidationError,
  WipAuthError, WipBulkItemError, WipNetworkError,
} from '@wip/client'

try {
  await client.defStore.getTerminology('nonexistent')
} catch (err) {
  if (err instanceof WipNotFoundError) {
    console.log('Not found:', err.message)
  } else if (err instanceof WipAuthError) {
    console.log('Auth failed:', err.statusCode)  // 401 or 403
  } else if (err instanceof WipNetworkError) {
    console.log('Network error:', err.cause)      // original Error
  } else if (err instanceof WipError) {
    console.log('WIP error:', err.statusCode, err.detail)
  }
}
```

### Single-Item vs. Bulk Error Handling

**Single-item convenience methods** throw on error:

```typescript
try {
  // Throws WipBulkItemError if the item fails
  await client.defStore.createTerminology({ value: 'EXISTING', label: 'Dup' })
} catch (err) {
  if (err instanceof WipBulkItemError) {
    console.log(err.index, err.itemStatus, err.message)
  }
}
```

**Bulk methods** return errors in `results[]` — they never throw for item-level failures:

```typescript
const response = await client.defStore.createTerminologies([
  { value: 'A', label: 'A' },
  { value: 'B', label: 'B' },
])

for (const item of response.results) {
  if (item.status === 'error') {
    console.log(`Item ${item.index} failed: ${item.error}`)
  } else {
    console.log(`Item ${item.index}: ${item.status}, id: ${item.id}`)
  }
}
console.log(`${response.succeeded}/${response.total} succeeded`)
```

---

## Utilities

### templateToFormSchema

Converts a WIP Template into framework-agnostic form field descriptors. Works with React, Vue, Svelte, or any UI framework.

```typescript
import { templateToFormSchema } from '@wip/client'

const template = await client.templates.getTemplateByValue('PATIENT_RECORD')
const formFields = templateToFormSchema(template)

// Each field has:
// - name, label, inputType ('text'|'number'|'select'|'file'|'group'|'list'|...)
// - required, defaultValue, isIdentity
// - terminologyCode (for term/select fields)
// - referenceType, targetTemplates (for reference/search fields)
// - fileConfig (for file fields: allowedTypes, maxSizeMb, multiple)
// - validation (pattern, minLength, maxLength, minimum, maximum, enum)
// - semanticType ('email', 'url', 'latitude', etc.)
// - arrayItemType, arrayTerminologyCode (for array/list fields)
```

**Input type mapping:**

| Template Field Type | Form Input Type |
|-------------------|----------------|
| `string` | `text` |
| `number` | `number` |
| `integer` | `integer` |
| `boolean` | `checkbox` |
| `date` | `date` |
| `datetime` | `datetime` |
| `term` | `select` |
| `reference` | `search` |
| `file` | `file` |
| `object` | `group` |
| `array` | `list` |

Identity fields are marked with `isIdentity: true` — use this to visually distinguish fields that determine document uniqueness.

### bulkImport

Batch-process large item lists with progress tracking and concurrency control.

```typescript
import { bulkImport } from '@wip/client'

const result = await bulkImport(
  largeTermList,  // e.g., 10,000 terms
  (batch) => client.defStore.createTerms(terminologyId, batch),
  {
    batchSize: 500,            // items per API call (default: 100)
    concurrency: 1,            // parallel batches (default: 1 — safe for Pi)
    continueOnError: true,     // keep going on failures (default: true)
    onProgress: ({ processed, total, succeeded, failed }) => {
      console.log(`${processed}/${total} (${failed} errors)`)
    },
  },
)
// result: { processed: 10000, total: 10000, succeeded: 9998, failed: 2 }
```

**Concurrency guidance:**
- `concurrency: 1` (default) — sequential, safe for Raspberry Pi
- `concurrency: 2-4` — parallel batches, good for faster hardware; overlaps network I/O with server processing

### resolveReference

Search for documents matching a reference field's target template. Useful for autocomplete/typeahead in forms.

```typescript
import { resolveReference } from '@wip/client'

const matches = await resolveReference(client, 'TPL-PATIENT', 'jane', 10)
// matches: [{ documentId, displayValue, identityFields }]
```

Currently fetches 100 recent documents and filters client-side. For large datasets, consider server-side search via `queryDocuments()`.

---

## Types

All types are exported from `@wip/client`:

```typescript
import type {
  // Client
  WipClient, WipClientConfig, AuthProvider,

  // Bulk operations
  BulkResponse, BulkResultItem, BulkImportProgress,

  // Terminologies & Terms
  Terminology, Term, TerminologyListResponse, TermListResponse,
  CreateTerminologyRequest, CreateTermRequest, UpdateTerminologyRequest,

  // Templates
  Template, FieldDefinition, ValidationRule, TemplateListResponse,
  CreateTemplateRequest, UpdateTemplateRequest,

  // Documents
  Document, DocumentListResponse, DocumentQueryRequest,
  CreateDocumentRequest, DocumentVersionResponse, TableViewResponse,

  // Files
  FileEntity, FileListResponse, FileUploadMetadata, FileIntegrityResponse,

  // Registry
  Namespace, RegistryEntryFull, RegistryLookupResponse, RegistrySearchResponse,
  RegistryByTermHit,

  // Ontology
  TermRelation, TermRelationListResponse, CreateTermRelationRequest, TraversalResponse,

  // Reporting
  IntegrityCheckResult, SearchResponse, ActivityResponse,

  // Errors
  WipError, WipNotFoundError, WipValidationError, WipAuthError,
  WipConflictError, WipServerError, WipNetworkError, WipBulkItemError,

  // Utilities
  FormField,
} from '@wip/client'
```

---

## Pagination

All list endpoints use consistent pagination:

```typescript
const page = await client.documents.listDocuments({
  page: 2,          // 1-based (default: 1)
  page_size: 25,    // default: 50, max: 100
})

page.items      // Document[]
page.total      // total matching records
page.page       // current page number
page.page_size  // items per page
page.pages      // total number of pages (ceil(total / page_size))
```

---

## BulkResponse Contract

Every write operation returns this shape (or throws for single-item convenience methods):

```typescript
interface BulkResponse {
  results: BulkResultItem[]
  total: number        // items submitted
  succeeded: number    // items that succeeded
  failed: number       // items that failed
  skipped?: number     // items skipped (e.g., duplicates with skip_duplicates=true)
}

interface BulkResultItem {
  index: number        // position in the input array
  status: string       // "created" | "updated" | "deleted" | "error" | "skipped"
  id?: string          // entity ID (on success)
  error?: string       // error message (on failure)
  value?: string       // entity value/code
  version?: number     // entity version (templates, documents)
  is_new?: boolean     // true if newly created (documents)
  identity_hash?: string  // document identity hash
  warnings?: string[]  // non-fatal warnings
}
```

---

## Further Reading

- **API conventions:** `docs/api-conventions.md` — bulk-first convention, BulkResponse contract, pagination rules
- **Data models:** `docs/data-models.md` — document, template, term models in detail
- **Uniqueness rules:** `docs/uniqueness-and-identity.md` — identity hashing, Registry synonyms, ID generation
- **Authentication:** `docs/authentication.md` — OIDC + API key dual auth
- **OpenAPI docs:** `http://localhost:{port}/docs` for each service (interactive Swagger UI)
- **React hooks:** See `@wip/react` for TanStack Query hooks wrapping this client
